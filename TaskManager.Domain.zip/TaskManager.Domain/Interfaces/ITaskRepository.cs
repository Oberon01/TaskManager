﻿
using TaskManager.Domain.Entities.Tasks;

namespace TaskManager.Domain.Interfaces;

// Repository interface for managing TaskItem entities
public interface ITaskRepository
{
    // Asynchronous methods for CRUD operations on TaskItem entities
    // Adds a new TaskItem to the repository
    Task AddAsync(TaskItem task, CancellationToken cancellationToken = default);

    // Updates an existing TaskItem in the repository
    Task UpdateAsync(TaskItem task, CancellationToken cancellationToken = default);

    // Deletes a TaskItem from the repository based on its unique identifier
    Task DeleteAsync(Guid taskId, CancellationToken cancellationToken = default);

    // Retrieves a TaskItem by its unique identifier, returning null if not found
    Task<TaskItem?> GetByIdAsync(Guid taskId, CancellationToken cancellationToken = default);

    // Retrieves all TaskItem entities from the repository
    Task<IEnumerable<TaskItem>> GetAllAsync(CancellationToken cancellationToken = default);
}